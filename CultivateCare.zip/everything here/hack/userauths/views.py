from django.shortcuts import render
def register_view(request):
    return render(request,'userauths/register.html')

# from django.shortcuts import render, redirect
# from .forms import SignUpForm, LogInForm
# from .models import User

# def signup(request):
#     if request.method == 'POST':
#         form = SignUpForm(request.POST)
#         if form.is_valid():
#             form.save()
#             # Redirect to login page after successful signup
#             return redirect('login')
#     else:
#         form = SignUpForm()
#     return render(request, 'register.html', {'form': form})

# def login(request):
#     if request.method == 'POST':
#         form = LogInForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']
#             # Authenticate user
#             user = User.objects.filter(username=username, password=password).first()
#             if user:
#                 # Redirect to home page after successful login
#                 return redirect('home')
#             else:
#                 # Handle invalid login
#                 pass
#     else:
#         form = LogInForm()
#     return render(request, 'login.html', {'form': form})