
from django.db import models
from django.contrib.auth.models import User,Group

from django.shortcuts import render,redirect

#models.py
# from django.db import models

# class User(models.Model):
#     full_name = models.CharField(max_length=100)
#     username = models.CharField(max_length=50, unique=True)
#     password = models.CharField(max_length=100)
#     country = models.CharField(max_length=100)
