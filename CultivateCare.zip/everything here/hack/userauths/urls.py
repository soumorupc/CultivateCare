from django.urls import path
from userauths import views

appname="userauths"
urlpatterns=[
    path("signup/", views.register_view, name="signup")
]

