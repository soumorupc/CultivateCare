# from django.shortcuts import redirect,render
# from django.http import HttpResponse
# from .forms import CreateUserForm
def home(request):
    return render(request, 'core/farmer.html')

# def Admin_register(request):
#     form=CreateUserForm()
#     if request.method=='POST':
#         form=CreateUserForm(request.POST)
#         print("USER REGISTEED")
#         if form.is_valid():
#             form.save()
#             return redirect('/')

#     context={'form':form}
#     return render(request,'core/register.html',context)
from django.shortcuts import render
import mysql.connector as sql

def signup(request):
    if request.method == 'GET':
        try:
            m = sql.connect(host="localhost", user="root", passwd="root", database='farmer')
            cursor = m.cursor()
            fn = request.GET.get('NAME', '')
            email = request.GET.get('EMAIL', '')
            pw = request.GET.get('PW1', '')
            pw2 = request.GET.get('PW2', '')
            loc = request.GET.get('LOC', '')

            print("Form Data:")
            print("Name:", fn)
            print("Email:", email)
            print("Password:", pw)
            print("Confirm Password:", pw2)
            print("Location:", loc)

            c = "INSERT INTO custom_farmer_table VALUES('{}','{}','{}','{}','{}')".format(fn, email, pw, pw2, loc)
            print("SQL Query:", c)
            cursor.execute(c)
            m.commit()
            print("Data inserted successfully")
        except Exception as e:
            print("Error:", e)
            m.rollback()  # Rollback the transaction if an error occurs
        finally:
            cursor.close()
            m.close()

    return render(request, 'farmer.html')


    #     form = SignUpForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         # Redirect to login page after successful signup
    #         return redirect('login')
    # else:
    #     form = SignUpForm()
    # return render(request, 'core/farmer.html', {'form': form})

# def login(request):
#     if request.method == 'POST':
#         form = LogInForm(request.POST)
#         if form.is_valid():
#             username = form.cleaned_data['username']
#             password = form.cleaned_data['password']
#             # Authenticate user
#             user = User.objects.filter(username=username, password=password).first()
#             if user:
#                 # Redirect to home page after successful login
#                 return redirect('/')
#             else:
#                 # Handle invalid login
#                 pass
#     else:
#         form = LogInForm()
#     return render(request, 'core/login.html', {'form': form})