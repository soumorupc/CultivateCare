# from django.urls import path
from core.views import *
# from core import views

# app_name="core"
# urlpatterns = [
    
#     path("", index),
#     path("users/", views.Admin_register,name="register")
# ]


from django.urls import path
from . import views

urlpatterns = [
    path("", views.home,name='home'),
    path('signup/', views.signup, name='signup'),
    #path('login/', views.login, name='login'),
    # Add other URL patterns as needed
]